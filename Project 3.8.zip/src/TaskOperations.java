/*
*Ian Crofford
*4/25/2026
*Project 3.8
*/

public interface TaskOperations {
    void createTask();
    void readTask();
    void updateTask();
    void deleteTask();
}
