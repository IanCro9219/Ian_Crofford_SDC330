/*
*Ian Crofford
*4/25/2026
*Project 3.8
*/
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("\nIan Crofford - Week 3 Project\n");

        TaskManager manager = new TaskManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("***TASK MANAGER***");
            System.out.println("1. Create Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("0. Exit");
            System.out.print("Choose: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manager.createTask();
                    break;
                case 2:
                    manager.readTask();
                    break;
                case 3: 
                    manager.updateTask();
                    break;
                case 4: 
                    manager.deleteTask();
                    break;
                case 0:
                    System.out.println("GoodBye!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 0);
        scanner.close();
    }
}
