/*
*Ian Crofford
*4/25/2026
*Project 3.8
*/

public class SimpleTask extends Task {
    public SimpleTask(int id, String title, String description, boolean isCompleted) {
        super(id, title, description, isCompleted);
    }

    @Override
    public void displayTask() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "ID: " + getId() + "\nTitle: " + getTitle() + "\nDescription: " + getDescription() + "\nCompleted: " + (isCompleted() ? "Yes" : "No");
    }
}
