/*
*Ian Crofford
*4/25/2026
*Project 3.8
*/

public class DatabaseManager {
    public void connect() {
        System.out.println("Database not yet added");
    }
    public void insertTask(Task task) {
        System.out.println("Not yet added.");
    }
    public void getTasks() {
        System.out.println("Not yet added.");
    }
    public void updateTask(Task task) {
        System.out.println("Not yet added.");
    }
    public void deleteTask(int id) {
        System.out.println("Not yet added.");
    }
}
