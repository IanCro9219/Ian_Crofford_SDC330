/*
*Ian Crofford
*4/25/2026
*Project 3.8
*/

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TaskManager implements TaskOperations {
    private List<Task> taskList;
    private Scanner scanner;

    public TaskManager() {
        taskList = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void addTask(Task task) {
        taskList.add(task);
    }

    public void viewTasks() {
        if (taskList.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }
        for (Task task : taskList) {
            task.displayTask();
        }
    }

    public void updateTaskById(int id) {
        for (Task task: taskList) {
            if (task.getId() == id) { 
            System.out.print("Enter new title: ");
            task.setTitle(scanner.nextLine());

            System.out.print("Enter new description: ");
            task.setDescription(scanner.nextLine());

            System.out.print("Is completed (true/false): ");
            task.setCompleted(scanner.nextBoolean());
            scanner.nextLine();

            System.out.println("Task updated.");
            return;
        }
    }
    System.out.println("Task not found");
}

public void deleteTaskById(int id) {
    taskList.removeIf(task -> task.getId() == id);
    System.out.println("Task deleted.");
}

@Override
public void createTask() {
    System.out.print("Enter ID: ");
    int id = scanner.nextInt();
    scanner.nextLine();

    System.out.print("Enter Title: ");
    String title = scanner.nextLine();

    System.out.print("Enter Description: ");
    String description = scanner.nextLine();

    Task task = new SimpleTask(id, title, description, false);
    addTask(task);

    System.out.println("Task added.");
}

@Override
public void readTask() {
    viewTasks();
}

@Override
public void updateTask() {
    System.out.print("Enter task ID to update: ");
    int id = scanner.nextInt();
    scanner.nextLine();
    updateTaskById(id);
}

@Override
public void deleteTask() {
    System.out.print("Enter task ID to delete: ");
    int id = scanner.nextInt();
    scanner.nextLine();
    deleteTaskById(id);
}

}
