/*
*Ian Crofford
*5/3/2026
*Description
*/
import java.util.Scanner;


public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("\nIan Crofford - Week 4 Database Implementation\n");

        TaskManager manager = new TaskManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n***Task Manager***");
            System.out.println("1. Create Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("0. Exit");
            System.out.print("Choose: ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Enter a number.");
                scanner.next();
            }

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manager.createTask();
                    break;
                case 2:
                    manager.readTask();
                    break;
                case 3:
                    manager.updateTask();
                    break;
                case 4:
                    manager.deleteTask();
                    break;
                case 0:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 0);
        scanner.close();
    }
}
