/*
*Ian Crofford
*5/3/2026
*Project 4.6
*Description: Concrete implementation of task that defines how a basic task is displayed
*/



public class SimpleTask extends Task {
    public SimpleTask(int id, String title, String description, boolean isCompleted) {
        super(id, title, description, isCompleted);
    }

    @Override
    public void displayTask() {
        System.out.println(toString());
        System.out.println("-------------------");
    }

    @Override
    public String toString() {
        return "ID: " + getId() +
        "\nTitle: " + getTitle() +
        "\nDescription: " + getDescription() +
        "\nCompleted: " + (isCompleted() ? "Yes" : "No");
    }
}
