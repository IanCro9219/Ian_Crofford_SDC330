/*
*Ian Crofford
*5/3/2026
*Project 4.6
*Description: Handles user input and coordinates task operations by interacting with the database. 
*/
import java.util.List;
import java.util.Scanner;

public class TaskManager implements TaskOperations {
    private Scanner scanner;
    private DatabaseManager db;

    public TaskManager() {
        scanner = new Scanner(System.in);
        db = new DatabaseManager();
        db.connect();
        db.createTable();
    }

    @Override
    public void createTask() {
        System.out.print("Enter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Title: ");
        String title = scanner.nextLine();

        if (title.isEmpty()) {
            System.out.println("Title cannot be empty.");
            return;
        }

        System.out.print("Enter Description: ");
        String description = scanner.nextLine();

        Task task = new SimpleTask(id, title, description, false);
        db.insertTask(task);
    }

    @Override
    public void readTask() {
        List<Task> tasks = db.getTask();

        System.out.println("\n***Task List***");
        if(tasks.isEmpty()) {
            System.out.println("No tasks found.");
            return;
        }

        for (Task task : tasks) {
            task.displayTask();
        }
    }

    @Override
    public void updateTask() {
        System.out.print("Enter ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("New Title: ");
        String title = scanner.nextLine();

        System.out.print("New Description: ");
        String description = scanner.nextLine();

        System.out.print("Completed (true/false): ");
        boolean completed = scanner.nextBoolean();
        scanner.nextLine();

        Task task = new SimpleTask(id, title, description, completed);
        db.updateTask(task);
    }

    @Override
    public void deleteTask() {
        System.out.print("Enter ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        db.deleteTask(id);
    }
}
