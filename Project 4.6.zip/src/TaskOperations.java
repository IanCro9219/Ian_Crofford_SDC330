/*
*Ian Crofford
*5/3/2026
*Project 4.6
*Description: Interface that defines the standard CRUD operations for managing tasks.
*/


public interface TaskOperations {
    void createTask();
    void readTask();
    void updateTask();
    void deleteTask();
}
