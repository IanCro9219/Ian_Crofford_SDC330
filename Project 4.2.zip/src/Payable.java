/*
*Ian Crofford
*5/3/2026
*Project 4.2
*Description: Interface that defines a method for calculating employee pay
 */


public interface Payable {
    double calculatePay();
}
