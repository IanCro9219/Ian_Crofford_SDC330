/*
*Ian Crofford
*5/3/2026
*Project 4.2
*Description: Represents a salaried employee and implements pay calculation based on salary 
*/


public class SalariedEmployee extends Employee implements Payable {
    private double salary;

    public SalariedEmployee(String name, double salary) {
        super(name);
        this.salary = salary;
    }

    public SalariedEmployee(String name) {
        this(name, 50000);

    }

    @Override
    public double calculatePay() {
        return salary;
    }

    @Override
    public String getDetails() {
        return "Type: Salaried\nName: " + getName() + "\nSalary: $" + salary;
    }
}
