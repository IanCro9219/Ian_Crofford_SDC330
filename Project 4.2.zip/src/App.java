/*
*Ian Crofford
*5/3/2026
*Project 4.2
*Description: Main Application that provides menu driven interface 
*/
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);

        System.out.println("\nIan Crofford - Week 4 Project");
        
        DatabaseManager db = new DatabaseManager();
        db.connect("employees.db");
        db.createTable();

        int choice;

        do {
            System.out.println("\n*** Menu ***");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Enter Choice: ");

            while (!input.hasNextInt()) {
                System.out.println("Invalid input. Enter a number.");
                input.next();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = input.nextLine();

                    System.out.print("Type (1 = Salaried, 2 = Hourly): ");
                    int type = input.nextInt();

                    if (type == 1) {
                        System.out.print("Enter salary: ");
                        double salary = input.nextDouble();
                        db.addEmployee(new SalariedEmployee(name, salary));
                    } else {
                        System.out.print("Enter hourly rate: ");
                        double rate = input.nextDouble();
                        System.out.print("Enter hours worked: ");
                        int hours = input.nextInt();
                        db.addEmployee(new HourlyEmployee(name, rate, hours));
                    }
                    break;
                case 2:
                    db.getAllEmployees();
                    break;
                case 3:
                    System.out.print("Enter ID to update: ");
                    int idUpdate = input.nextInt();
                    input.nextLine();
                    System.out.print("Enter new name: ");
                    String newName = input.nextLine();
                    db.updateEmployee(idUpdate, newName);
                    break;
                case 4:
                    System.out.print("Enter ID to delete: ");
                    int idDelete = input.nextInt();
                    db.deleteEmployee(idDelete);
                    break;
            }
        } while (choice != 5);

        System.out.println("Goodbye!");
        input.close();
        

    }
}
