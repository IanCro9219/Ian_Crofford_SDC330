/*
*ian Crofford
*5/3/2026
*Project 4.2
*Description: Handles SQLit database connection and CRUD operations
*/
import java.sql.*;


public class DatabaseManager {
    private Connection conn;

    public void connect(String dbName) {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:" + dbName);
            System.out.println("Connected to database.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }

    public void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS employees (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        "name TEXT," +
        "type TEXT," +
        "salary REAL," +
        "hourlyRate REAL," +
        "hoursWorked INTEGER)";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void addEmployee(Employee e) {
        String sql = "INSERT INTO employees(name, type, salary, hourlyRate, hoursWorked) VALUES(?,?,?,?,?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (e instanceof SalariedEmployee) { 
            pstmt.setString(1, e.getName());
            pstmt.setString(2, "Salaried");
            pstmt.setDouble(3,((SalariedEmployee) e).calculatePay());
            pstmt.setNull(4, Types.NULL);
            pstmt.setNull(5, Types.NULL);
            } else if (e instanceof HourlyEmployee) {
                HourlyEmployee h = (HourlyEmployee) e;
                pstmt.setString(1, h.getName());
                pstmt.setString(2, "Hourly");
                pstmt.setNull(3, Types.NULL);
                pstmt.setDouble(4, h.calculatePay() / h.getHoursWorked());
                pstmt.setInt(5, h.getHoursWorked());
            }
            pstmt.executeUpdate();
            System.out.println("Employee added.");
        } catch (SQLException e1) {
            System.out.println(e1.getMessage());
        }
        
    }

    public void getAllEmployees() {
        String sql = "SELECT * FROM employees";

        try (Statement stmt = conn.createStatement();
    ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            System.out.println("\nID: " + rs.getInt("id") +
                                "\nName: " + rs.getString("name") +
                                "\nType: " + rs.getString("type") +
                                "\nSalary: " + rs.getDouble("salary") +
                                "\nHourly Rate: " + rs.getDouble("hourlyRate") +
                                "\nHours: " + rs.getInt("hoursWorked")
                                );
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    }

    public void updateEmployee(int id, String newName) {
        String sql = "UPDATE employees SET name = ? WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newName);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            System.out.println("Employee updated.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("Employee deleted.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
