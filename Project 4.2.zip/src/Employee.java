/*
*Ian Crofford
*5/3/2026
*Project 4.2
*Description: Abstract base c lass that definess a common property
*/


public abstract class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract String getDetails();
}
