/*
*Ian Crofford
*5/3/2026
*Project 4.2
*Description: Represents an hourly employee and calculates pay base on rate and hours worked
*/


public class HourlyEmployee extends Employee implements Payable {
    private double hourlyRate;
    private int hoursWorked;

    public HourlyEmployee(String name, double rate, int hours) {
        super(name);
        this.hourlyRate = rate;
        this.hoursWorked = hours;
    }

    public HourlyEmployee(String name, double rate) {
        this(name, rate, 0);
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    @Override
    public double calculatePay() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public String getDetails() {
        return "Type: Hourly\nName: " + getName() +
        "\nRate: $" + hourlyRate +
        "\nHours: " + hoursWorked;
    }
}
