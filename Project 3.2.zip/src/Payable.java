/*
*Ian Crofford
*4/25/2026
*Project 3.2
*Purpose: Interface for calculating employee pay
*/

public interface Payable {
    double calculatePay();
}
