/*
*Ian Crofford
*4/25/2026
*Project 3.2
*Purpose: Represents a salaried employee
*/

public class SalariedEmployee extends Employee implements Payable {
    private double salary;

    public SalariedEmployee(String name, double salary) {
        super(name);
        this.salary = salary;
    }

    public SalariedEmployee(String name) {
        this(name, 50000);
    }

    @Override
    public double calculatePay() {
        return salary;
    }

    @Override
    public String getDetails() {
        return "Type: Salaried\nName: " + getName() + "\nSalary: $" + salary + "\nPay: $" + calculatePay();
    }
}
