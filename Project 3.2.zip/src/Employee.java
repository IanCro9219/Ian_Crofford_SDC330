/*
*Ian Crofford
*4/25/2026
*Project 3.2
*Purpose: Abstract base class representing a general employee
*/

public abstract class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract String getDetails();
}
