/*
*Ian Crofford
*4/25/2026
*Project 3.2
*Purpose: Represents an hourly employee
*/

public class HourlyEmployee extends Employee implements Payable {
    private double hourlyRate;
    private int hoursWorked;

    public HourlyEmployee(String name, double rate, int hours) {
        super(name);
        this.hourlyRate = rate;
        this.hoursWorked = hours;
    }

    public HourlyEmployee(String name, double rate) {
        this(name, rate, 0);
    }

    @Override
    public double calculatePay() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public String getDetails() {
        return "Type: Hourly\nName: " + getName() + "\nRate: $" + hourlyRate + "\nHours: " + hoursWorked + "\nPay: $" + calculatePay();
    }
}
