/*
*Ian Crofford
*4/25/2026
*Project 3.8
*Purpose: Main application demonstrating abstraction, constructors, and access specifiers
*/
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Ian Crofford - Week 3 Project");
        System.out.println("Employee Management Application");
        System.out.println("This program demonstrates abstraction, constructors, and access specifiers.\n");

        System.out.println("Welcome! you can view employee details and calculated pay.");

        Department dept = new Department("IT Department");

        Employee e1 = new SalariedEmployee("Ian Crofford", 60000);
        Employee e2 = new HourlyEmployee("Jane Doe", 25, 40);

        dept.addEmployee(e1);
        dept.addEmployee(e2);

        int choice;

        do {
            System.out.println("\n***Menu***");
            System.out.println("1. View Employees");
            System.out.println("2. Exit");
            System.out.print("Enetr Choice: ");

            choice = input.nextInt();

            if (choice == 1) {
                dept.displayEmployees();
            }
        } while (choice != 2);
        System.out.println("Goodbye!");
        input.close();
    }
}
