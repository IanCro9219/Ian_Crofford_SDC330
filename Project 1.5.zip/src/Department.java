/*
*Ian Crofford
*4/10/2026
*Project 1.5
*/

import java.util.ArrayList;

public class Department {
 private String departmentName;
 private ArrayList<Employee> employees;
 
 public Department(String name) {
    this.departmentName = name;
    employees = new ArrayList<>();
 }

 public void addEmployee(Employee e) {
    employees.add(e);

 }
 public void displayEmployees() {
    System.out.println("\nDepartment: " + departmentName);

    for (Employee e : employees) {
        System.out.println("\n" + e.getDetails());
    }
 }
}
