/*
*Ian Crofford
*4/10/2026
*Project 1.5
*/

public class HourlyEmployee extends Employee {
    private double hourlyRate;

    public HourlyEmployee(String name, double rate) {
        super(name);
        this.hourlyRate = rate;
    }

    @Override
    public String getDetails() {
        return "Type: Hourly\nName: " + name + "\nRate: $" + hourlyRate;
    }
}
