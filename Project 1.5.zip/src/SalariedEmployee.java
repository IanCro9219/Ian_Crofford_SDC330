/*
*Ian Crofford
*4/10/2026
*Project 1.5 */

public class SalariedEmployee extends Employee {
    private double salary;

    public SalariedEmployee(String name, double salary) {
        super(name);
        this.salary = salary;
    }

    @Override
    public String getDetails() {
        return "Type: Salaried\nName: " + name + "\nSalary: " + salary;
    }
}
