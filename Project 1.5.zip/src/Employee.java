/*
*Ian Crofford
*4/10/2026
*Project 1.5
*/

public class Employee {
    protected String name;

    public Employee(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public String getDetails() {
        return "Employee Name: " + name;
    }
}
