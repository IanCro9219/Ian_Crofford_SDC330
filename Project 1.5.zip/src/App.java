/*
*Ian Crofford
*4/10/2026
*Project 1.5
*/

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
    
        Scanner input = new Scanner(System.in);

        System.out.println("Ian Crofford - Week 1 Project");
        System.out.println("Employee Management Application");
        System.out.println("\nWelcome!\n\nChoose an option:\n");

        Department dept = new Department("IT Department");

        Employee e1 = new SalariedEmployee("John Smith", 60000);
        Employee e2 = new HourlyEmployee("Jane Doe", 25);

        dept.addEmployee(e1);
        dept.addEmployee(e2);

        int choice;

        do {
            System.out.println("\n1. View Employees");
            System.out.println("2. Exit");
            System.out.print("Enter Choice: ");

            choice = input.nextInt();

            if (choice ==1) {
                dept.displayEmployees();
            }
        } while (choice != 2);
        System.out.println("Goodbye!");

        input.close();
    }
    
}
