/*
*Ian Crofford
*4/16/2026
*Project 2.2
Purpose: Represents a salaried employee
*Demonstrates: Inheritance + Interface + Polymorphism */

public class SalariedEmployee extends Employee implements Payable {
    private double salary;

    public SalariedEmployee(String name, double salary) {
        super(name);
        this.salary = salary;
    }

    @Override
    public double calculatePay() {
        return salary;
    }

    @Override
    public String getDetails() {
        return "Type: Salaried\nName: " + name + "\nSalary: $" + salary + "\nPay: $" + calculatePay();
    }
}
