/*
*Ian Crofford
*4/16/2026
*Project 2.2
*Purpose: Main Application with user interaction
*/
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);

        System.out.println("Ian Crofford - Week 2 Project");
        System.out.println("Employee Management Application");
        System.out.println("This program demonstrates interfaces and polymorphism.\n");

        Department dept = new Department("IT Department");

        Employee e1 = new SalariedEmployee("Ian Crofford", 60000);
        Employee e2 = new HourlyEmployee("Jane Does", 25, 40);

        dept.addEmployee(e1);
        dept.addEmployee(e2);

        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. View Employees");
            System.out.println("2. Exit");
            System.out.print("Enter Choice: ");

            choice = input.nextInt();

            if (choice == 1) {
                dept.displayEmployees();
            }
        } while (choice != 2);
        System.out.println("Goodbye!");
        input.close();
    }
}
