/*
*Ian Crofford
*4/16/2026
*Project 2.2
*Purpose: Represents an hourly employee
*Demonstrates: Inheritance + Interface + Polymorphism
*/

public class HourlyEmployee extends Employee implements Payable {
    private double hourlyRate;
    private int hoursWorked;

    public HourlyEmployee(String name, double rate, int hours) {
        super(name);
        this.hourlyRate = rate;
        this.hoursWorked = hours;
    }

    @Override
    public double calculatePay() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public String getDetails() {
        return "Type: Hourly\nName: " + name + "\nRate: $" + hourlyRate + "\nHours: " + hoursWorked + "\nPay: $" + calculatePay();
    }
}
