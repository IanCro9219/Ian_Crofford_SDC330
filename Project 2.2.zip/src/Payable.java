/*
*Ian Crofford
*4/16/2026
*Project 2.2
*Purpose: Interface for calculating employee pay
*Demonstrates: Interface creation
*/

public interface Payable {
    double calculatePay();
}
