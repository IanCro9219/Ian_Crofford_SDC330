/*
*Ian Crofford
*4/16/2026
*Project 2.2
*Purpose: Stores and manages employees
*Demostrates: Composition + Polymorphism
*/
import java.util.ArrayList;

public class Department {
private String departmentName;
private ArrayList<Employee> employees;

public Department(String name) {
    this.departmentName = name;
    employees = new ArrayList<>();
}

public void addEmployee(Employee e) {
    employees.add(e);
}

public void displayEmployees() {
    System.out.println("\nDepartment: " + departmentName);

    for (Employee e : employees) {
        System.out.println("\n" + e.getDetails());

        if (e instanceof Payable) {
            Payable p = (Payable) e;
            System.out.println("Calculated Pay: $" + p.calculatePay());
        }
    }
}
}
