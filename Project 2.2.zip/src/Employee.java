/*
*Ian Crofford
*4/16/2026
*Project 2.2
*Purpose: Base Class representing a general employee
* Demostrates: Base class for inheritance
*/

public class Employee {
    protected String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getDetails() {
        return "Employee Name: " + name;
    }
}